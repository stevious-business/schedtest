#include "../lib/operations.h"
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char delim[2] = "/";

static int locate_inode(file_system* fs, char* path, enum node_type seek_type) {
	// Check parameter validity
	if (fs == NULL || path == NULL || path[0] != delim[0]) { return -1; }
	int idx = fs->root_node;
	char* p = malloc(16384);
	strcpy(p, path);
	char* tok = strtok(p, delim);
	char* seeked;
	if (tok == NULL) { free(p); return fs->root_node; }
	while (1) {
		seeked = strtok(NULL, delim);
		for (int dbidx = 0; dbidx<=DIRECT_BLOCKS_COUNT; dbidx++) {
			if (dbidx == DIRECT_BLOCKS_COUNT) {
				free(p);
				return -1;
			}
			int tidx = fs->inodes[idx].direct_blocks[dbidx];
			if (!strcmp(tok, fs->inodes[tidx].name)) {
				// if last element, we care about seek_type - unless it's free_block which is a wildcard
				if (seeked != NULL || fs->inodes[tidx].n_type == seek_type || seek_type == free_block) {
					idx = tidx;
					break;
				}
			}
		}
		if (seeked == NULL) {
			break;
		}
		tok = seeked;
	}
	free(p);
	return idx;
}

int
fs_mkdir(file_system *fs, char *path)
{
	if (fs == NULL || path == NULL || path[0] != delim[0]) {
		return -1; // Invalid path
	}
	// Find parent
	char* tmp = strdup(path);

	if (locate_inode(fs, path, directory) != -1)
	{ return -1; } // Already exists
	strrchr(tmp, delim[0])[0] = 0;
	if (tmp[0] == 0) { strncpy(tmp, delim, 2); }
	int p_inode = locate_inode(fs, tmp, directory);
	free(tmp);
	if (p_inode == -1) { return -1; }


	// Find free inode
	int idx = find_free_inode(fs);
	// Update parent direct_blocks
	for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
		if (i == DIRECT_BLOCKS_COUNT) { return -1; } // Parent dir full
		if (fs->inodes[p_inode].direct_blocks[i] == -1) {
			fs->inodes[p_inode].direct_blocks[i] = idx;
			break;
		}
	}
	// Check for availability
	if (idx == -1 || p_inode == -1) {
		return -1;
	}

	// No errors, free to go
	fs->inodes[idx].n_type = directory; // Set type to directory
	strncpy(fs->inodes[idx].name, strrchr(path, delim[0])+1, NAME_MAX_LENGTH); // Copy name
	fs->inodes[idx].parent = p_inode; // Set parent to parent
	return 0;
}

int
fs_mkfile(file_system *fs, char *path_and_name)
{
	if (fs == NULL || path_and_name == NULL || path_and_name[0] != delim[0]) {
		return -1;
	}
	// Find parent
	char* tmp = strdup(path_and_name);

	if (locate_inode(fs, path_and_name, reg_file) != -1)
	{ return -2; } // Already exists
	strrchr(tmp, delim[0])[0] = 0;
	if (tmp[0] == 0) { strncpy(tmp, delim, 2); }
	int p_inode = locate_inode(fs, tmp, directory);
	free(tmp);
	if (p_inode == -1) { return -1; }

	// Find free inode
	int idx = find_free_inode(fs);
	// Update parent direct_blocks
	for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
		if (i == DIRECT_BLOCKS_COUNT) { return -1; } // Parent dir full
		if (fs->inodes[p_inode].direct_blocks[i] == -1) {
			fs->inodes[p_inode].direct_blocks[i] = idx;
			break;
		}
	}
	// Check for availability
	if (idx == -1 || p_inode == -1) {
		return -1;
	}

	for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
		if (!strcmp(strrchr(path_and_name, delim[0])+1, fs->inodes[fs->inodes[p_inode].direct_blocks[i]].name) && \
			fs->inodes[fs->inodes[p_inode].direct_blocks[i]].n_type == reg_file) {
			return -1; // File already exists
		}
	}

	// No errors, free to go
	fs->inodes[idx].n_type = reg_file; // Set type to directory
	strncpy(fs->inodes[idx].name, strrchr(path_and_name, delim[0])+1, NAME_MAX_LENGTH); // Copy name
	fs->inodes[idx].parent = p_inode; // Set parent to parent

	return 0;
}

char *
fs_list(file_system *fs, char *path)
{
	if (fs == NULL || path == NULL || path[0] != delim[0]) { return NULL; }
	int name_length = (5+NAME_MAX_LENGTH)*DIRECT_BLOCKS_COUNT;
	char* out = (char*) calloc(name_length, sizeof(char));

	if (fs == NULL || path == NULL) {
		return out; // Invalid path
	}

	int p_inode = locate_inode(fs, path, free_block);

	if (p_inode == -1) {
		return out;
	}

	int floor = -1;
	int idx = -1;
	int ceil = (int)fs->s_block->num_blocks; // Maximal possible index

	while (1) {
		for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
			if (floor < fs->inodes[p_inode].direct_blocks[i] && fs->inodes[p_inode].direct_blocks[i] < ceil) {
				ceil = fs->inodes[p_inode].direct_blocks[i];
				idx = i;
			}
		}
		if (idx > -1) { // if we found a fitting value
			switch (fs->inodes[fs->inodes[p_inode].direct_blocks[idx]].n_type)
			{
			case (directory):
				strcat(out, "DIR ");
				strcat(out, fs->inodes[fs->inodes[p_inode].direct_blocks[idx]].name);
				strcat(out, "\n");
				break;
			case (reg_file):
				strcat(out, "FIL ");
				strcat(out, fs->inodes[fs->inodes[p_inode].direct_blocks[idx]].name);
				strcat(out, "\n");
				break;
			default:
				fprintf(stderr, "Found OK index for p_inode %d: %d\n", p_inode, fs->inodes[p_inode].direct_blocks[idx]);
				fprintf(stderr, "Direct block should not be a free block! (Found index %d with n_type %d)\n", idx, fs->inodes[fs->inodes[p_inode].direct_blocks[idx]].n_type);
				return out;
			}
		}
		else {
			break;
		}
		floor = ceil;
		ceil = (int)fs->s_block->num_blocks;
		idx = -1;
	}

	return out;
}

int
fs_writef(file_system *fs, char *filename, char *text)
{
	if (fs == NULL || filename == NULL || filename[0] != delim[0]) {
		return -1; // Invalid path or action
	}
	if (strlen(text) == 0) { return 0; }
	
	int p_inode = locate_inode(fs, filename, reg_file);
	if (p_inode == -1) { return -1; }

	int size = fs->inodes[p_inode].size;
	int tlen = strlen(text);
	int dbidx = -1;

	if (size % BLOCK_SIZE == 0) {
		// We must allocate another block
		int widx = -1;
		for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
			if (fs->inodes[p_inode].direct_blocks[DIRECT_BLOCKS_COUNT-i-1] == -1) {
				widx = DIRECT_BLOCKS_COUNT-i-1;
			}
		}
		if (widx == -1) { return -2; }
		if (fs->s_block->free_blocks == 0) { return -2; }

		// Find new free datablock
		for (int i = 0; i<fs->s_block->num_blocks; i++) {
			if (fs->free_list[i] == 1) {
				// Hit!
				fs->free_list[i] = 0;
				fs->s_block->free_blocks--;
				fs->inodes[p_inode].direct_blocks[widx] = i;
				dbidx = i;
				break;
			}
		}
	}
	else {
		// Already partially filled block exists
		dbidx = fs->inodes[p_inode].direct_blocks[size / BLOCK_SIZE];
	}

	// Find maximal write size
	int wsize = BLOCK_SIZE - size % BLOCK_SIZE >= tlen ? tlen : BLOCK_SIZE - size % BLOCK_SIZE;
	// Write data
	memcpy(fs->data_blocks[dbidx].block+size%BLOCK_SIZE, text, wsize);
	fs->inodes[p_inode].size += wsize;
	fs->data_blocks[dbidx].size += wsize;
	if (tlen > wsize) { return wsize + fs_writef(fs, filename, text+wsize); }

	return wsize;
}

uint8_t *
fs_readf(file_system *fs, char *filename, int *file_size)
{
	if (fs == NULL || filename == NULL || filename[0] != delim[0]) {
		return NULL; // Invalid path
	}
	int p_inode = locate_inode(fs, filename, reg_file);
	if (p_inode == -1) { return NULL; }

	*file_size = fs->inodes[p_inode].size;

	if (fs->inodes[p_inode].size == 0) { return NULL; }

	uint8_t* buf = calloc(fs->inodes[p_inode].size, sizeof(uint8_t));

	int s = 0;

	for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
		int dbidx = fs->inodes[p_inode].direct_blocks[i];
		if (dbidx > -1) {
			memcpy(buf+s, fs->data_blocks[dbidx].block, fs->data_blocks[dbidx].size);
			s += fs->data_blocks[dbidx].size;
		}
	}
	return buf;
}

int
fs_rm(file_system *fs, char *path)
{
	if (fs == NULL || path == NULL || path[0] != delim[0]) { return -1; }
	if (!strcmp(path, "/")) { fprintf(stderr, "Blocked attempt to remove root!\n"); return -1; }

	char* tmp = strdup(path);

	if (locate_inode(fs, path, free_block) == -1)
	{ return -1; } // Doesn't exist
	strrchr(tmp, delim[0])[0] = 0;
	if (tmp[0] == 0) { strncpy(tmp, delim, 2); }
	int p_inode = locate_inode(fs, tmp, directory);
	if (p_inode == -1) { free(tmp); return -1; }

	tmp = strdup(path);
	int c_inode = locate_inode(fs, tmp, free_block);
	free(tmp);
	if (c_inode == -1) { return -1; }

	if (fs->inodes[c_inode].n_type == reg_file) {
		for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
			int dbidx = fs->inodes[c_inode].direct_blocks[i];
			if (dbidx > -1) {
				fs->free_list[dbidx] = 1;
				fs->data_blocks[dbidx].size = 0;
				fs->s_block->free_blocks++;
			}
		}
	}
	else {
		for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
			if (fs->inodes[c_inode].direct_blocks[i] > -1) {
				char* cname = strdup(path); // "/a/b/c" + "/" + "name"
				if (strcmp(strrchr(cname, delim[0])+1, "\0")) { // If cname doesnt already end with /
					strcat(cname, "/");
				}
				strcat(cname, fs->inodes[fs->inodes[c_inode].direct_blocks[i]].name);
				fs_rm(fs, cname);
				free(cname);
			}
		}
	}
	inode_init(&(fs->inodes[c_inode]));
	for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
		if (fs->inodes[p_inode].direct_blocks[i] == c_inode) {
			fs->inodes[p_inode].direct_blocks[i] = -1;
			return 0;
		}
	}
	fprintf(stderr, "Internal logic error!\n");
	return -1;
}

int
fs_import(file_system *fs, char *int_path, char *ext_path)
{
	if (int_path == NULL || ext_path == NULL || fs == NULL || int_path[0] != delim[0]) {
		return -1;
	}
	FILE* ext_fil = fopen(ext_path, "r");
	if (ext_fil == NULL) { return -1; }
	fseek(ext_fil, 0, SEEK_END);
	long int len = ftell(ext_fil);
	fseek(ext_fil, 0, SEEK_SET);
	uint8_t* buf = calloc(len, sizeof(uint8_t));
	if (buf == NULL) { fclose(ext_fil); return -1; }
	fread(buf, sizeof(uint8_t), len, ext_fil);
	fclose(ext_fil);
	fs_writef(fs, int_path, (char*)buf);
	return 0;
}

int
fs_export(file_system *fs, char *int_path, char *ext_path)
{
	if (int_path == NULL || ext_path == NULL || fs == NULL || int_path[0] != delim[0]) {
		return -1;
	}
	int size = 0;
	uint8_t* buf = fs_readf(fs, int_path, &size);
	if (buf == NULL) { return -1; }
	FILE* ext_fil = fopen(ext_path, "w");
	if (ext_fil == NULL) { free(buf); return -1; }
	fwrite(buf, sizeof(uint8_t), size, ext_fil);
	fclose(ext_fil);
	free(buf);
	return 0;
}
