#include "../lib/operations.h"
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static const char delim[2] = "/";

int
fs_mkdir(file_system *fs, char *path)
{
	// Find directory name
	char* token = strtok(strdup(path), delim);
	char* ptok = token;
	int p_inode = fs->root_node;
	char tmppath[256] = "";

	while (token != NULL) {
		ptok = token;
		strcat(tmppath, delim);
		strcat(tmppath, ptok);
		for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
			if (i == DIRECT_BLOCKS_COUNT && strcmp(tmppath, path)) {
				return -1; // Subdirectory does not exist; exit
			}
			int child_node = fs->inodes[p_inode].direct_blocks[i];
			if (!strcmp(token, fs->inodes[child_node].name)) {
				p_inode = child_node;
				break;
			}
		}
		token = strtok(NULL, delim);
	}

	if (fs->inodes[p_inode].direct_blocks[DIRECT_BLOCKS_COUNT-1] != -1) {
		return -1; // Parent dir full
	}

	int idx = find_free_inode(fs);
	if (idx == -1) {
		return -1; // File system full
	}
	fs->inodes[idx].n_type = directory;

	strncpy(fs->inodes[idx].name, ptok, NAME_MAX_LENGTH);
	fs->inodes[idx].parent = p_inode;
	for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
		if (fs->inodes[p_inode].direct_blocks[i] == -1) {
			fs->inodes[p_inode].direct_blocks[i] = idx;
			break;
		}
	}

	return 0;
}

int
fs_mkfile(file_system *fs, char *path_and_name)
{
	char* token = strtok(strdup(path_and_name), delim);
	char* ptok = token;
	int p_inode = fs->root_node;
	char tmppath[256] = "";

	while (token != NULL) {
		ptok = token;
		strcat(tmppath, delim);
		strcat(tmppath, ptok);
		for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
			if (i == DIRECT_BLOCKS_COUNT && strcmp(tmppath, path_and_name)) {
				return -1; // Subdirectory does not exist; exit
			}
			int child_node = fs->inodes[p_inode].direct_blocks[i];
			if (!strcmp(token, fs->inodes[child_node].name)) {
				p_inode = child_node;
				break;
			}
		}
		token = strtok(NULL, delim);
	}

	if (fs->inodes[p_inode].direct_blocks[11] != -1) {
		return -1; // Parent dir full
	}

	int idx = find_free_inode(fs);
	if (idx == -1) {
		return -1; // File system full
	}
	fs->inodes[idx].n_type = reg_file;

	//printf("DIRNAME %s; INODE %d\n", ptok, idx);

	strncpy(fs->inodes[idx].name, ptok, NAME_MAX_LENGTH);
	fs->inodes[idx].parent = p_inode;
	//fs->inodes[p_inode].direct_blocks.append(idx)
	for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
		if (fs->inodes[p_inode].direct_blocks[i] == -1) {
			fs->inodes[p_inode].direct_blocks[i] = idx;
			break;
		}
	}

	return 0;
}

char *
fs_list(file_system *fs, char *path)
{
	//// TODO: Sort by inode index ////
	// Find parent inode
	char* token = strtok(strdup(path), delim);
	char* ptok = token;
	int p_inode = fs->root_node;
	char tmppath[256] = "";

	int s = (4+NAME_MAX_LENGTH)*fs->s_block->num_blocks;

	char out[s];

	memcpy(out, "\0", s);

	while (token != NULL) {
		ptok = token;
		strcat(tmppath, delim);
		strcat(tmppath, ptok);
		for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
			if (i == DIRECT_BLOCKS_COUNT) {
				return strdup(out); // Subdirectory does not exist; exit
			}
			int child_node = fs->inodes[p_inode].direct_blocks[i];
			if (!strcmp(token, fs->inodes[child_node].name)) {
				p_inode = child_node;
				break;
			}
		}
		token = strtok(NULL, delim);
	}

	int i = 0;
	while (fs->inodes[p_inode].direct_blocks[i] > -1) {
		// Step through child inodes
		if (fs->inodes[fs->inodes[p_inode].direct_blocks[i]].n_type == reg_file) {
			// Found file
			inode file_inode = fs->inodes[fs->inodes[p_inode].direct_blocks[i]];
			strcat(out, "FIL ");
			strcat(out, file_inode.name);
			strcat(out, "\n");
		}
		else if (fs->inodes[fs->inodes[p_inode].direct_blocks[i]].n_type == directory) {
			// Found dir
			inode dir_inode = fs->inodes[fs->inodes[p_inode].direct_blocks[i]];
			strcat(out, "DIR ");
			strcat(out, dir_inode.name);
			strcat(out, "\n");
		}
		i++;
	}

	
	return strdup(out);
}

int
fs_writef(file_system *fs, char *filename, char *text)
{
	char* token = strtok(strdup(filename), delim);
	char* ptok = token;
	int p_inode = fs->root_node;
	char tmppath[256] = "";

	while (token != NULL) {
		ptok = token;
		strcat(tmppath, delim);
		strcat(tmppath, ptok);
		for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
			if (i == DIRECT_BLOCKS_COUNT) {
				fprintf(stderr, "Failed to find object %s in %s (path %s)!\n", ptok, fs->inodes[p_inode].name, tmppath);
				return -1; // Subdirectory does not exist; exit
			}
			int child_node = fs->inodes[p_inode].direct_blocks[i];
			if (!strcmp(token, fs->inodes[child_node].name)) {
				p_inode = child_node;
				break;
			}
		}
		token = strtok(NULL, delim);
	}
	
	if (fs->inodes[p_inode].n_type == directory) {
		fprintf(stderr, "IsADirectory: Given file path is a directory!\n");
		return -1;
	}

	int tlen = strlen(text); // Text length to be written

	if (fs->s_block->free_blocks < tlen / BLOCK_SIZE) {
		fprintf(stderr, "Not enough remaining free blocks!\n");
		return -1;
	}
	else if (fs->s_block->free_blocks == tlen / BLOCK_SIZE) {
		;; // Potentially not enough remaining free blocks
	}

	int t_offset = 0; // Text offset
	int primary_block = fs->inodes[p_inode].size / BLOCK_SIZE; // Points to first writable data block
	int base_idx = fs->inodes[p_inode].direct_blocks[primary_block];
	if (base_idx != -1) {
		// Block already partially filled
		int ptr_offset = fs->inodes[p_inode].size % BLOCK_SIZE;
		int wsize = BLOCK_SIZE - fs->inodes[p_inode].size % BLOCK_SIZE >= tlen ? tlen : BLOCK_SIZE-fs->inodes[p_inode].size%BLOCK_SIZE;
		memcpy((uint8_t*)&fs->data_blocks[base_idx].block+ptr_offset, text, wsize);
		fs->inodes[p_inode].size += wsize;
		fs->data_blocks[base_idx].size += wsize;
		tlen -= wsize;
		t_offset += wsize;
		primary_block++;
	}

	int fb_idx = 0; // Free block index
	while (tlen > 0) {
		if (fs->s_block->free_blocks == 0) {
			fprintf(stderr, "Ran out of space while trying to write. Your files are most likely corrupted.\n");
			return -1;
		}
		// Find new data block
		while (fs->free_list[fb_idx] == 0) {
			fb_idx++;
		}
		fs->free_list[fb_idx] = 0;
		
		int wsize = tlen >= BLOCK_SIZE ? BLOCK_SIZE : tlen;
		memset(&fs->data_blocks[fb_idx].block, 0, BLOCK_SIZE); // set to 0 before cloning data
		memcpy(&fs->data_blocks[fb_idx].block, text+t_offset, wsize);
		tlen -= wsize;
		t_offset += wsize;
		fs->inodes[p_inode].size += wsize;
		fs->data_blocks[fb_idx].size += wsize;
		fs->inodes[p_inode].direct_blocks[primary_block] = fb_idx;
		fs->s_block->free_blocks--;
		primary_block++;
	}

	return t_offset; // Not ideal but equivalent to bytes written
}

uint8_t *
fs_readf(file_system *fs, char *filename, int *file_size)
{
	char* token = strtok(strdup(filename), delim);
	char* ptok = token;
	int p_inode = fs->root_node;
	char tmppath[256] = "";

	while (token != NULL) {
		ptok = token;
		strcat(tmppath, delim);
		strcat(tmppath, ptok);
		for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
			if (i == DIRECT_BLOCKS_COUNT) {
				fprintf(stderr, "Failed to find object %s in %s (path %s)!\n", ptok, fs->inodes[p_inode].name, tmppath);
				return NULL; // Subdirectory does not exist; exit
			}
			int child_node = fs->inodes[p_inode].direct_blocks[i];
			if (!strcmp(token, fs->inodes[child_node].name)) {
				p_inode = child_node;
				break;
			}
		}
		token = strtok(NULL, delim);
	}
	
	if (fs->inodes[p_inode].n_type == directory) {
		fprintf(stderr, "IsADirectory: Given file path is a directory!\n");
		return NULL;
	}

	*file_size = fs->inodes[p_inode].size;

	if (*file_size == 0) {
		//fprintf(stderr, "Empty file!\n");
		return NULL;
	}

	uint8_t* out = (uint8_t*)calloc(*file_size, sizeof(uint8_t));

	int rsize = *file_size;
	int offset = 0; // Block offset

	while (rsize > 0) {
		memcpy(&out[offset*BLOCK_SIZE], fs->data_blocks[fs->inodes[p_inode].direct_blocks[offset]].block, rsize >= BLOCK_SIZE ? BLOCK_SIZE : rsize);
		rsize -= rsize >= BLOCK_SIZE ? BLOCK_SIZE : rsize;
		offset++;
	}

	return out;	
}


int
fs_rm(file_system *fs, char *path)
{
	char* token = strtok(strdup(path), delim);
	char* ptok = token;
	int p_inode = fs->root_node;
	int parent_idx = fs->root_node;
	char tmppath[256] = "";

	while (token != NULL) {
		ptok = token;
		strcat(tmppath, delim);
		strcat(tmppath, ptok);
		for (int i = 0; i<=DIRECT_BLOCKS_COUNT; i++) {
			if (i == DIRECT_BLOCKS_COUNT) {
				fprintf(stderr, "Failed to find object %s in %s (path %s)!\n", ptok, fs->inodes[p_inode].name, tmppath);
				return -1; // Subdirectory does not exist; exit
			}
			int child_node = fs->inodes[p_inode].direct_blocks[i];
			if (!strcmp(token, fs->inodes[child_node].name)) {
				parent_idx = p_inode;
				p_inode = child_node;
				break;
			}
		}
		token = strtok(NULL, delim);
	}

	if (fs->inodes[p_inode].n_type == reg_file) {
		for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
			if (fs->inodes[p_inode].direct_blocks[i] != -1) {
				fs->free_list[fs->inodes[p_inode].direct_blocks[i]] = 1; // Free data block
			}
		}
	}
	else {
		for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
			if (fs->inodes[p_inode].direct_blocks[i] != -1) {
				char* subpath = strdup(path);
				strcat(subpath, delim);
				strcat(subpath, fs->inodes[fs->inodes[p_inode].direct_blocks[i]].name);
				fs_rm(fs, subpath);
			}
		}
	}
	inode_init(&fs->inodes[p_inode]); // reset inode
	for (int i = 0; i<DIRECT_BLOCKS_COUNT; i++) {
		if (fs->inodes[parent_idx].direct_blocks[i] == p_inode) { // Reset direct block in parent
			fs->inodes[parent_idx].direct_blocks[i] = -1;
		}
	}
	return 0;
}

int
fs_import(file_system *fs, char *int_path, char *ext_path)
{
	return -1;
}

int
fs_export(file_system *fs, char *int_path, char *ext_path)
{
	return -1;
}